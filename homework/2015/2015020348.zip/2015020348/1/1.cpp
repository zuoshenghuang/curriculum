﻿#include <iostream>
#include <vector>
using namespace std;
vector<long> v;

void Delete(int * ptr){
   
    delete ptr;
    ptr=NULL;
    v.erase(v.begin()+1);

}

int main(){
    //vector<long> v;
    int i=0;
    int *p = new int;
    int *q = new int;
    long a = (long)&p;
    long b = (long)&q;
    v.push_back(a);
  
    v.push_back(b);
  
    for(int n : v) {
        std::cout << n << endl;

    }
    cout<<"_________________________"<<endl;
    Delete(q);
    
    for(int n : v) {
        std::cout << n << endl;

    }

}