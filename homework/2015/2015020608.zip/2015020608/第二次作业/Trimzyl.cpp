#include <iostream>
using namespace std;
#include <ctime>

clock_t Begin,End;
double duration;

void trim(string & s,string sep)
{
   size_t pos =s.find_first_of(sep);
   //cout<<sep.length()<<endl;
   //char s1=sep[sep.length()-1];
  // cout<<s1<<endl;
   //char s2 = s[pos+sep.length()-1];
   //cout<<s2<<endl;
  while(pos != std::string::npos){
      
          s.erase(pos,sep.length());
     cout<<s<<endl;
      pos =s.find_first_of(sep);
  }
}

void trimtest()
{
    string str = "my chinese name is zhaoyunlong";
    string a = "my";
    trim(str,a);
    cout<<"001:"<<str<<endl;

    str = "Brazil,Russia,India,China,South Africa";
    string b = "ia";
    trim(str,b);
    cout<<"002:"<<str<<endl;

}

int main()
{
    Begin = clock();
    trimtest();
    End = clock();
    duration = double(End - Begin)/CLK_TCK;
    cout<<"tick ="<<double(End-Begin)<<endl;
    cout<<"DURATION ="<<duration<<endl;
    system("pause");
    return 0;

}