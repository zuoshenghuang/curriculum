//btree.h
//1.前序遍历算法
void PreOrder(BTreeNode * BT)
{
    if (BT!=NULL)
    {
        cout<<BT->data<<' ';  // 访问根结点
        PreOrder(BT->left);     // 前序遍历左子树
        PreOrder(BT->right);   // 前序遍历右子树
    }
}
//2.中序遍历算法
void InOrder(BTreeNode * BT)
{
    if (BT!=NULL)
    {
        InOrder(BT->left);        // 中序遍历左子树
        cout<<BT->data<<' ';   // 访问根结点
        InOrder(BT->right);      // 中序遍历右子树
    }
}
//3.后序遍历算法
void PostOrder(BTreeNode * BT)
{
    if (BT!=NULL)
    {
        PostOrder(BT->left);     // 后序遍历左子树
        PostOrder(BT->right);   // 后序遍历右子树
        cout<<BT->data<<' ';  // 访问根结点
    }
}
//4 按层遍历算法
//此算法为一个非递归算法，具体描述如下：
void LevelOrder(BTreeNode * BT)
// 按层遍历由BT指针所指向的二叉树
{
    const int MaxSize=30;
    BTreeNode * q[MaxSize];
    // 定义队列所使用的数组空间，元素类型为指向结点的指针类型
    int front = 0, rear = 0;
    // 定义队首指针和队尾指针，初始均置0表示空队
    BTreeNode * p;
    if (BT!= NULL)
    {
        rear=(rear+1)%30; //在向队列插入结点指针之前后称队尾指针
        q[rear]=BT; //将树根指针进队，也可称为将树根结点进队
    }
    while(front!=rear)
    {     // 当队列非空时执行循环
        front=(front+1)%30;
        // 在从队列中删除结点指针之前后移队首指针
        p=q[front];  // 删除队首结点的值
        cout<<p->data<<' ';    // 输出队首结点的值
        if (p->left!=NULL)
        {   // 若结点存在左孩子，则左孩子结点指针进队
            rear=(rear+1)%30;
            q[rear]=p->left;
        }
        if (p->right!=NULL)
        {   // 若结点存在右孩子，则右孩子结点指针进队
            rear=(rear+1)%30;
            q[rear]=p->right;
        }
    }
}
//1初始化二叉树
void InitBTree(BTreeNode * & BT)
// 初始化二叉树，即把树根指针置空
{
    BT=NULL;
}
//       建立二叉树的算法描述为：
void CreateBTree(BTreeNode*& BT, char* a)
//根据字符串a所给出的用广义表表示的二叉树建立对应的存储结构
{
    const int MaxSize=100;
    //栈数组长度要大于等于二叉树的深度减1
    BTreeNode* s[MaxSize];
    //s数组作为存储根结点指针的栈使用
    int top=-1;  //top作为栈顶指针，初值为-1，表示空栈
    BT=NULL;     //把树根指针置为空，即从空树开始
    BTreeNode* p=NULL;//定义p为指向二叉树结点的指针
    int k=0;    //用k作为处理结点的左子树和右子树的标记，
    //k=1处理左子树，k=2处理右子树
    int i=0; //用i扫描数组a中存储的二叉树广义表字符串
    while (a[i])
    {//每循环一次处理一个字符，直到扫描到字符串结束符'\0'为止
        switch(a[i]) {
            case ' ':  //对空格不作任何处理
                break;
            case '(':
                if(top==MaxSize-1) {
                    cout<<"栈空间太小，请增加MaxSize的值!"<<endl;
                    exit(1);
                }
                top++; s[top]=p; k=1;
                break;
            case ')':
                if(top==-1) {
                    cout<<"二叉树广义表字符串错!"<<endl; exit(1);
                }
                top--; break;
            case ',':
                k=2; break;
            default:   //只可能为字符，即结点值
                p=new BTreeNode;
                p->data=a[i]; p->left=p->right=NULL;
                if(BT==NULL) BT=p;   //作为根结点插入
                else {
                    if(k==1) s[top]->left=p;//作为左孩子插入
                    else s[top]->right=p; //作为右孩子插入
                }
        }  //switch end
        i++;  //为扫描下一个字符修改i值
    }
}
//3检查二叉树是否为空
bool EmptyBTree (BTreeNode * BT)
// 判断一棵二叉树是否为空，若是则返回1，否则返回0
{
    return BT==NULL;
}
//4 求二叉树深度
int DepthBTree(BTreeNode * BT)
// 求由BT指针指向的一棵二叉树的深度
{
    if (BT==NULL)
        return 0;    // 对于空树，返回0并结束递归
    else
    {
        // 计算左子树的深度
        int dep1=DepthBTree(BT->left);
        // 计算右子树的深度
        int dep2=DepthBTree(BT->right);
        // 返回树的深度
        if (dep1>dep2)
            return dep1+1;
        else
            return dep2+1;
    }
}
//5 从二叉树中查找值为X的结点，若存在则由X带回完整值并返回真，否则返回假
bool FindBTree(BTreeNode* BT,ElemType& x)
{
    if(BT==NULL)return false;
    else {
        if(BT->data==x){x=BT->data;return true;}
        else {
            if(FindBTree(BT->left,x)) return true;
            if(FindBTree(BT->right,x)) return true;
            return false;//左右子树查找均失败，返回假
        }
    }
}
//6输出二叉树
void PrintBTree (BTreeNode * BT)
// 按照树的一种表示方法输出一棵二叉树
{
    if (BT!=NULL)
    {    // 树为空时结束递归，否则执行如下操作
        cout<<BT->data;   // 输出根结点的值
        if (BT->left!=NULL||BT->right!=NULL)
        {
            cout<<'(';      // 输出左括号
            PrintBTree(BT->left);    // 输出左子树
            if (BT->right!=NULL)
                cout<<',';//若右子树不为空则输出逗号分隔符
            PrintBTree(BT->right);    // 输出右子树
            cout<<')';// 输出右括号
        }
    }
}
//7清除二叉树
void ClearBTree(BTreeNode * BT)
{
    if (BT!=NULL)
    {    // 当二叉树非空时进行如下操作
        ClearBTree(BT->left);  // 删除左子树
        ClearBTree(BT->right);        // 删除右子树
        delete BT;              // 删除根结点
        BT=NULL;
    }
}
void PreOrderNN(BTreeNode * BT)
{
    BTreeNode * s[20]; //此栈 记每次变量
    int flag[20];//此栈 记断点续接处
    int top=-1,f=0; //f为0 从头开始1 递归结束 断点续接
    BTreeNode *p=BT;
    if (p==NULL) return;
    while(1)
    {
        if (f==1)
        {    //断点续接
            if (flag[top]==1) goto L1;
            if (flag[top]==2) goto L2;
        }
        else
        {
            if (p==NULL)
            {f=1;continue;}//本次递归结束。
            else
                ;// 从头开始
        }
        cout<<p->data<<' ';
        //变量入栈保护，递归准备，进行递归
        s[++top]=p;flag[top]=1;p=p->left;f=0;continue;
    L1:     //第一次递归的断点续接，变量出栈，程序继续
        p=s[top--];//<<top<<" ";cin>>k;
        //变量入栈保护，递归准备，进行递归
        s[++top]=p;flag[top]=2;p=p->right;f=0;continue;
    L2:     //第二次递归的断点续接，变量出栈，程序继续
        p=s[top--];
        if (p==BT) break;//最后回到最原始非递归程序，退出循环。
        f=1;
    }
}
void PostOrderNN(BTreeNode * BT)
{
    BTreeNode * s[20]; //此栈 记每次变量
    int flag[20];//此栈 记断点续接处
    int top=-1,f=0;//f为0从头开始1递归结束 断点续接
    BTreeNode *p=BT;
    if (p==NULL) return;
    while(1)
    {
        if (f==1)
        {    //断点续接
            if (flag[top]==1) goto L1;
            if (flag[top]==2) goto L2;
        }
        else
        {
            if (p==NULL)
            {f=1;continue;}//本次递归结束。
            else
                ;// 从头开始
        }
        //变量入栈保护，递归准备，进行递归
        s[++top]=p;flag[top]=1;p=p->left;f=0;continue;
    L1:     //第一次递归的断点续接，变量出栈，程序继续
        p=s[top--];
        //变量入栈保护，递归准备，进行递归
        s[++top]=p;flag[top]=2;p=p->right;f=0;continue;
    L2:     //第二次递归的断点续接，变量出栈，程序继续
        p=s[top--];cout<<p->data<<' ';//<<top<<" ";cin>>k;
        if (p==BT) break;//最后回到最原始非递归程序，退出循环。
        f=1;
    }
}
void InOrderN(BTreeNode * BT)
{
    BTreeNode * s[20];
    int top=-1;
    BTreeNode *p=BT;
    while(top!=-1 || p!=NULL)
    {
        while(p!=NULL) {
            s[++top]=p;
            p=p->left;
        }
        if(top!=-1) {
            p=s[top--];
            cout<<p->data<<' ';
            p=p->right;
        }
    }
}
void InOrderNN(BTreeNode * BT)
{
    BTreeNode * s[20]; //此栈 记每次变量
    int flag[20];//此栈 记断点续接处
    int top=-1,f=0;//f为0从头开始1递归结束 断点续接
    BTreeNode *p=BT;
    if (p==NULL) return;
    while(1)
    {
        if (f==1)
        {    //断点续接
            if (flag[top]==1) goto L1;
            if (flag[top]==2) goto L2;
        }
        else
        {
            if (p==NULL)
            {f=1;continue;}//本次递归结束。
            else
                ;// 从头开始
        }
        //变量入栈保护，递归准备，进行递归
        s[++top]=p;flag[top]=1;p=p->left;f=0;continue;
    L1:     //第一次递归的断点续接，变量出栈，程序继续
        p=s[top--];cout<<p->data<<' ';//<<top<<" ";cin>>k;
        //变量入栈保护，递归准备，进行递归
        s[++top]=p;flag[top]=2;p=p->right;f=0;continue;
    L2:     //第二次递归的断点续接，变量出栈，程序继续
        p=s[top--];
        if (p==BT) break;//最后回到最原始非递归程序，退出循环。
        f=1;
    }
}

//
//  btree.h
//  bstree
//
//  Created by zhaoyunlong on 2017/11/29.
//  Copyright © 2017年 zhaoyunlong. All rights reserved.
//


