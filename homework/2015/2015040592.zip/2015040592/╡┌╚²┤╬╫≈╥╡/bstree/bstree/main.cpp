//
//  main.cpp
//  bstree
//
//  Created by zhaoyunlong on 2017/11/29.
//  Copyright © 2017年 zhaoyunlong. All rights reserved.
//

#include<iostream>
using namespace std;
#include<stdlib.h>
typedef char ElemType; //定义二叉树中元素的类型为字符型
struct BTreeNode {   // 定义二叉树的结点类型
    ElemType data;   // 值域
    BTreeNode * left;    // 左指针域
    BTreeNode * right;     // 右指针域
};
#include "btree.h" // 此头文件中包含有对二叉树进行各种操作的算法
int main()
{
    BTreeNode* bt;
    // 定义指向二叉树结的指针，并用它作为树根指针
    InitBTree(bt);
    // 初始化二叉树，即置树根指针bt为空
    char b[50];
    // 定义一个用于存放二叉树广义表的字符数组
    cout<<"输入二叉树广义表表示的字符串："<< endl;
    cin.getline(b,sizeof(b));//输入的字符串被放入b数组中
    CreateBTree(bt,b);
    // 建立以bt作为树根指针的二叉树的链接存储结构
    PrintBTree(bt); cout<<endl; // 以广义表形式输出二叉树
    cout<<"前序:";PreOrder(bt);cout<<endl;
    // 前序遍历以bt为树根指针的二叉树
    cout<<"中序:";InOrder(bt);cout<<endl;
    // 中序遍历以bt为树根指针的二叉树
    cout<<"后序:";PostOrder(bt);cout<<endl;
    // 后序遍历以bt为树根指针的二叉树
    cout<<"按层:";LevelOrder(bt);cout<<endl;
    // 按层遍历以bt为树根指针的二叉树的深度
    ElemType x;
    cout<<"输入一个待查字符：";cin>>x;
    if(FindBTree(bt,x)) cout<<"查找字符"<<x<<"成功！";
    else  cout<<"查找字符"<<x<<"失败！";
    cout<<endl;
    cout<<"二叉树的深度为：";
    cout<<DepthBTree (bt)<<endl;
    // 求出以bt为树根指针的二叉树的深度
    ClearBTree(bt);
    // 清除以bt为树根指针的二叉树
}

