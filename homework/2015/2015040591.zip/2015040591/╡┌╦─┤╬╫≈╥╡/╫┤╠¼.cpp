#include <iostream>
using namespace std;
 
class Context;
 
class State
{
public:
     virtualvoidHandle(Context*pContext)=0;
};
 
classConcreteStateA:publicState
{
public:
     virtual void Handle(Context*pContext)
     {
          cout<<"I am concretestateA."<<endl;
     }
};
 
class ConcreteStateB:publicState
{
public:
     virtual void Handle(Context*pContext)
     {
          cout<<"I am concretestateB."<<endl;
     }
};
 
class Context
{
public:
     Context(State*pState):m_pState(pState){}
 
     void Request()
     {
          if(m_pState)
          {
               m_pState->Handle(this);
          }
     }
 
     void ChangeState(State*pState)
     {
          m_pState=pState;
     }
 
private:
     State*m_pState;
};
 
int main()
{
     State*pStateA=newConcreteStateA();
     State*pStateB=newConcreteStateB();
     Context*pContext=newContext(pStateA);
     pContext->Request();
 
     pContext->ChangeState(pStateB);
     pContext->Request();
 
     delete pContext;
     delete pStateB;
     delete pStateA;
}