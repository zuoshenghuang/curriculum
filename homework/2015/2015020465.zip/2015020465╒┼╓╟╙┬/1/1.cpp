#include <iostream>  
using namespace std;  
const int QUEUEITEM_SIZE = 100000;  
template<typename T>  
class Queue  
{  
public:  
    Queue()  
    {  
        _prear = _pfirst = new QueueItem();  
    }  
    ~Queue()  
    {  
        QueueItem  * pcur = _pfirst;  
        while (pcur != NULL)  
        {  
            _pfirst = _pfirst->_pnext;  
            delete   pcur;  
           pcur = _pfirst;  
        }  
        delete _pfirst;  
    }  
    void addQue(const T &val);  
    void delQue();  
    T top();  
    bool empty()const;  
    void showQueue();  
private:  
    class QueueItem  
    {  
    public:  
        QueueItem(T data=T()):_data(data),_pnext(NULL){};  
          
        //������Ĭ�Ͼʹ�����static����  
        void* operator new(size_t size)  
        {  
            QueueItem *p = _pfreelist;  
            //�ж��ڴ���Ƿ����  
            if(_pfreelist == NULL)  
            {  
                int mysize = QUEUEITEM_SIZE * size;//�ܵ��ֽ���  
                _pfreelist = (QueueItem*)new char[mysize];  
                //����������ʽ��������  
                for(p = _pfreelist; p < _pfreelist+QUEUEITEM_SIZE-1; ++p)  
                {  
                    p->_pnext = p+1;//��һ�����  
                }  
                p->_pnext = NULL;//���һ����㵥��������  
            }  
  
            _pfreelist = _pfreelist->_pnext;  
            return p;//�����ѷ����ȥ�Ľ��  
        }  
        void operator delete(void *ptr)  
        {  
            if(ptr == NULL)  
            {  
                return;  
            }  
            //�黹���ڴ��  
            QueueItem *p = (QueueItem *)ptr;  
            p->_pnext = _pfreelist;  
            _pfreelist = p;  
        }  
  
        T _data;  
        QueueItem *_pnext;  
        static QueueItem *_pfreelist;//��̬��Ա���������������ʼ��  
    };  
    QueueItem *_pfirst;  
    QueueItem *_prear;  
};  
  
template<typename T>  
typename Queue<T>::QueueItem *Queue<T>::QueueItem::_pfreelist = NULL;//Ƕ���࣬��������������  
  
template<typename T>  
void Queue<T>::addQue(const T& val)  
{  
    QueueItem *tmp = new QueueItem(val);  
    if (_prear == NULL)  
    {     
        _prear = tmp;  
        _pfirst = tmp;  
        return ;  
    }  
    _prear ->_pnext = tmp;  
    _prear = tmp;  
}  
  
template<typename T>  
void Queue<T>::delQue()  
{  
    QueueItem *pcur = _pfirst->_pnext;  
    if(pcur == NULL)  
        return;  
    if(pcur->_pnext == NULL)  
        _prear = _pfirst;  
    _pfirst->_pnext = pcur->_pnext;  
    delete pcur;  
}  
  
template<typename T>  
T  Queue<T>::top()  
{  
    return _pfirst->_pnext->_data;  
}  
  
template<typename T>  
bool Queue<T>::empty()const  
{  
    return _pfirst == _prear;  
}  
  
  
template<typename T>  
void Queue<T>::showQueue()  
{  
    QueueItem *pcur = _pfirst->_pnext;  
    while(pcur != NULL)  
    {  
        cout<<pcur->_data<<" ";  
        pcur = pcur->_pnext;  
    }  
    cout<<endl;  
}  
  
  
int main()  
{  
    //  100000QueueItem�Ľڵ�  
    Queue<int> intQueue;  
  
    intQueue.addQue(10);  
    intQueue.addQue(4);  
    intQueue.addQue(67);  
    intQueue.addQue(21);  
    intQueue.addQue(5);  
    intQueue.addQue(9);  
    intQueue.addQue(31);  
  
    intQueue.delQue();  
    intQueue.delQue();  
    intQueue.delQue();  
      
    intQueue.showQueue();  
    cout<<intQueue.top()<<endl;  
      
    return 0;  
}