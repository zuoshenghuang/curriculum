#include "stdafx.h"
#include <iostream>
#include <string>

void trim(std::string & s, char a)
{
	for (int i = 0; i<s.length(); i++)
	{
		if (s[i] == a)
		{
			size_t pos = i;
			s.erase(pos,1);
		}
	}
}
void trim0(std::string & s, std::string sep)
{
	if (s.empty())
		return;

	size_t pos = s.find_first_of(sep);
	while (pos != std::string::npos)
	{
		s.erase(pos, 1);
		pos = s.find_first_of(sep);
	}
}
void test_trim()
{
	std::string str = "my chinese name is Huang xx";
	char a = ' ';
		trim(str, a);
	//trim0(str," ")
	std::cout << str << std::endl;

	str = "Brazil,Russia,India,China,South Africa";
	char b = ',';
	trim(str, b);
	//trim0(str, ",");
	std::cout << str << std::endl;

}

int main()
{
	test_trim();
	system("pause");
	return 0;
}


