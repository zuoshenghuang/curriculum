void lTrim(char*str)
{
    int i , len ;

    len = strlen( str ) ;
    for( i=0; i<len; i++)
    {
        if( str[i] != ' ') break ;
    }
    memmove(str,str+i,len-i+1);
    return ;
}
