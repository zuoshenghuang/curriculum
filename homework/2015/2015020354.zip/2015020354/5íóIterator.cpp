01. #include <iostream>  
02. #include <vector>  
03. using namespace std;  
04.   
05. template<class Item>  
06. class Iterator  
07. {  
08. public:  
09.     virtual void first()=0;  
10.     virtual void next()=0;  
11.     virtual Item* currentItem()=0;  
12.     virtual bool isDone()=0;  
13.     virtual ~Iterator(){}  
14. };  
15.   
16. template<class Item>  
17. class ConcreteAggregate;  
18.   
19. template<class Item>  
20. class ConcreteIterator : public Iterator <Item>  
21. {  
22.     ConcreteAggregate<Item> * aggr;  
23.     int cur;  
24. public:  
25.     ConcreteIterator(ConcreteAggregate<Item>*a):aggr(a),cur(0){}  
26.     virtual void first()  
27.     {  
28.         cur=0;  
29.     }  
30.     virtual void next()  
31.     {  
32.         if(cur<aggr->getLen())  
33.             cur++;  
34.     }  
35.     virtual Item* currentItem()  
36.     {  
37.         if(cur<aggr->getLen())  
38.             return &(*aggr)[cur];  
39.         else  
40.             return NULL;  
41.     }  
42.     virtual bool isDone()  
43.     {  
44.         return (cur>=aggr->getLen());  
45.     }  
46. };  
47.   
48. template<class Item>  
49. class Aggregate  
50. {  
51. public:  
52.     virtual Iterator<Item>* createIterator()=0;  
53.     virtual ~Aggregate(){}  
54. };  
55.   
56. template<class Item>  
57. class ConcreteAggregate:public Aggregate<Item>  
58. {  
59.     vector<Item >data;  
60. public:  
61.     ConcreteAggregate()  
62.     {  
63.         data.push_back(1);  
64.         data.push_back(2);  
65.         data.push_back(3);  
66.     }  
67.     virtual Iterator<Item>* createIterator()  
68.     {  
69.         return new ConcreteIterator<Item>(this);  
70.     }  
71.     Item& operator[](int index)  
72.     {  
73.         return data[index];  
74.     }  
75.     int getLen()  
76.     {  
77.         return data.size();  
78.     }  
79. };  
80.   
81. int main()  
82. {  
83.     Aggregate<int> * aggr =new ConcreteAggregate<int>();  
84.     Iterator<int> *it=aggr->createIterator();  
85.   
86.     for(it->first();!it->isDone();it->next())  
87.     {  
88.         cout<<*(it->currentItem())<<endl;  
89.     }  
90.     delete it;  
91.     delete aggr;  
92.     return 0;  
93. }  