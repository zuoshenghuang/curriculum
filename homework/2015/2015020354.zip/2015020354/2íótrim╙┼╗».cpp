#include <iostream>
#include <string>
#include<ctime>
clock_t  begin, end;

void trim(std::string & s, std::string sep)
{
	if (s.empty())
		return;
	size_t pos = s.find_first_of(sep);
	while (pos != std::string::npos)
	{
		s.erase(pos, sep.size());
		pos = s.find_first_of(sep);
	}
}
void test_trim()
{
	std::string str = "my chinese name is Huang xx";
	trim(str, " ");
	std::cout << str << std::endl;
	str = "Brazil,Russia,India,China,South Africa";
	trim(str, ",");
	std::cout << str << std::endl;
}
int main()
{ 
	begin = clock();
    test_trim();
    end = clock();
	std::cout << "tick=" << double(end - begin) << std::endl;
	system("pause");
    return 0;
}