public abstract class Element {
    String name;
    int age;
    String university;
    String skill;
    public Element(String name,int age,String unversity,String skill){
        this.name = name;
        this.age = age;
        this.university = unversity;
        this.skill = skill;
    }
    abstract void accept(Visitor visitor);
}
