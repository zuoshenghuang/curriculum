#include<iostream>
#include<assert.h>
void* malloc2(size_t size)
{
	void* m = (void*)malloc(size);
	assert(m);
	return m;
}

char* trim(const char* str)
{
	char *trimed;
	int tail;
	int head;

	head = 0;
	assert(str);

	tail = strlen(str) - 1;
	while (tail >= 0 && isspace(str[tail]))
	{
		--tail;
	}
	while (isspace(str[head]))
	{
		++head;
	}

	if (tail < head) {
		trimed = (char *)malloc2(sizeof(char));
		*trimed = '\0';
		return trimed;
	}

	trimed = (char *)malloc2(sizeof(char) * (tail - head + 2));
	strncpy(trimed, str + head, (tail - head + 1));
	trimed[tail - head + 1] = '\0';
	return trimed;
}
