#include<iostream>
#include<list>
template <class _Tp, class _Alloc>
void list<_Tp, _Alloc>::sort()
{
	   // Do nothing if the list has length 0 or 1.  
	   if (_M_node->_M_next != _M_node && _M_node->_M_next->_M_next != _M_node) {
		     list<_Tp, _Alloc> __carry;
	         list<_Tp, _Alloc> __counter[64];
	         int __fill = 0;
             while (!empty()) {
                   __carry.splice(__carry.begin(), *this, begin());
				   int __i = 0;
	               while (__i < __fill && !__counter[__i].empty()) {
		                  __counter[__i].merge(__carry);
		                  __carry.swap(__counter[__i++]);
				
			}
                  __carry.swap(__counter[__i]);
                  if (__i == __fill) ++__fill;
			
		}
             for (int __i = 1; __i < __fill; ++__i)
		     __counter[__i].merge(__counter[__i - 1]);
             swap(__counter[__fill - 1]);
	}
}

	typedef std::list<Student>::iterator Iter;
    for(Iter it = v.begin(); it != v.end(); it++)
		it->show();
}

int main()
{
	//test_list();
	//test_sort();
	test_sort_student();
	system("pause");
	return 0;
}
