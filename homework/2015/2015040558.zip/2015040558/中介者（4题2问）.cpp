package com.shusheng.pattern.mediator;
import java.util.ArrayList;
import java.util.List;
import com.shusheng.pattern.mediator.Person.Sex;

public class MarriageAgencyImpl implements MarriageAgency {

    List<Man> men = new ArrayList<>();
    List<Woman> women = new ArrayList<>();

    @Override
    public void pair(Person person) {//���
        if (person.sex == Sex.MALE) {
            for (Woman woman : women)
                if (woman.age == person.requestAge) {
                    System.out.println(person.name + "��" + woman.name + "��Գɹ�");
                    return;
                }
        } else if (person.sex == Sex.FEMALE) {
            for (Man man : men) {
                if (man.age == person.requestAge) {
                    System.out.println(person.name + "��" + man.name + "��Գɹ�");
                    return;
                }
            }
        }
        System.out.println("û��Ϊ"+person.name+"�ҵ����ʵĶ���");
    }


    @Override
    public void register(Person person) {
        if (person.sex == Sex.MALE)
            men.add((Man) person);
        else if (person.sex == Sex.FEMALE)
            women.add((Woman) person);
    }
}