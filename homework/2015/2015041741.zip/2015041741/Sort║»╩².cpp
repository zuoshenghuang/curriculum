#include"stdafx.h"
#include <list> 
#include <iomanip> 
#include<iostream>
using namespace std;
//the max value is 64 
const int SCALE = 10;
template <typename T>
void print_dbg(list<T>& iList, list<T>& carry, list<T>* counter)
{
	typename list<T>::iterator it2;

	cout << "list: ";
	it2 = iList.begin();
	while (it2 != iList.end())
	{
		cout << setw(3) << *it2++;
	}
	cout << endl;

	cout << "carry: ";
	it2 = carry.begin();
	while (it2 != carry.end())
	{
		cout << setw(3) << *it2++;
	}
	cout << endl;

	for (int i = 0; i<SCALE; ++i)
	{
		if (!counter[i].empty())
		{
			cout << "counter[" << i << "]: ";
			it2 = counter[i].begin();
			while (it2 != counter[i].end())
			{
				cout << setw(3) << *it2++;
			}
			cout << endl;
		}
	}
	cout << endl << endl;
}
template <typename T>
void LSort(list<T> &iList)
{
	if (iList.size() <= 1)
	{
		return;
	}

	list<T> carry;
	list<T> counter[64];
	int fill = 0;
	typename list<T>::iterator it;

	while (!iList.empty())
	{
		carry.splice(carry.begin(), iList, iList.begin());
		print_dbg(iList, carry, counter);

		int i = 0;
		while (i < fill && !counter[i].empty())
		{
			counter[i].merge(carry);
			carry.swap(counter[i++]);
		}

		carry.swap(counter[i]);
		print_dbg(iList, carry, counter);
		if (i == fill)
		{
			++fill;
		}
		cout << endl << endl << endl;
	}

	for (int i = 1; i < fill; ++i)
	{
		counter[i].merge(counter[i - 1]);
	}

	print_dbg(iList, carry, counter);

	iList.swap(counter[fill - 1]);
}

int main()
{
	int arr[] = { 22,43,1,32,43,3,65,8,56,98,4,23,87,94,37,77,35,36,0 };
	list<int> iList(arr, arr + sizeof(arr) / sizeof(int));
	list<int>::iterator it;
	LSort(iList);
    cout << "Complete! After sort: " << endl;
	it = iList.begin();
	while (it != iList.end())
	{
		cout << setw(3) << *it++;
	}
	cout << endl << endl;
	system("pause");
	return 0;
}

