/** 
 
* �Զ��弯�Ͻӿ�, ����java.util.Collection 
 
* �������ݴ洢 
 
* @author stone 
 
* 
 
*/ 

public interface ICollection<T> { 
   
  
IIterator<T> iterator(); //���ص����� 
  
void add(T t); 
  
T get(int index); 

} 

/** 
 
* �Զ���������ӿ� ������java.util.Iterator 
 
* ���ڱ���������ICollection������ 
 
* @author stone 
 
* 
 
*/ 

public interface IIterator<T> { 
  
boolean hasNext(); 
  
boolean hasPrevious(); 
  
T next(); 
  
T previous(); 

} 
** 
 
* �����࣬ ������MyIterator 
 
* @author stone 
 
*/ 

public class MyCollection<T> implements 
ICollection<T> { 
 
  
private T[] arys; 
  
private int index = -1; 
  
private int capacity = 5; 
   
  
public MyCollection() { 
    
this.arys = (T[]) new Object[capacity]; 
  
} 
   
  
@Override 
  
public IIterator<T> iterator() { 
    
return new MyIterator<T>(this); 
  
} 
   
  
@Override 
  
public void add(T t) { 
    
index++; 
    
if (index == capacity) { 
      
capacity *= 2; 
      
this.arys = Arrays.copyOf(arys, capacity); 
       
    
} 
    
this.arys[index] = t; 
  
} 
   
  
@Override 
 
 public T get(int index) { 
    
return this.arys[index]; 
  
} 
   

} 


/* 
 
* �����µĴ洢�ṹ����new һ��ICollection�� ��Ӧ�� new һ��IIterator��ʵ�����ı��� 
 
*/ 

@SuppressWarnings({"rawtypes", "unchecked"}) 

public class Test { 
  
public static void main(String[] args) { 
    
ICollection<Integer> collection = new MyCollection<Integer>(); 
    
add(collection, 3, 5, 8, 12, 3, 3, 5); 
    
for (IIterator<Integer> iterator = collection.
iterator(); iterator.hasNext();) { 
      
System.out.println(iterator.next()); 
    
} 
     
    
System.out.println("-------------"); 
     
    
ICollection collection2 = new MyCollection(); 
    
add(collection2, "a", "b", "c", 3, 8, 12, 3, 5); 
    
for (IIterator iterator = collection2.iterator(); iterator.hasNext();) { 
      System.out.println(iterator.next()); 
   
 } 
     
  
} 
   
  
static <T> void add(ICollection<T> c, T ...a) { 
    
for (T i : a) { 
      
c.add(i); 
    
  } 
  
 } 
}