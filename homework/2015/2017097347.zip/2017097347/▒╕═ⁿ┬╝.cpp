public class Memento {
    private int state;
    public Memento(int state){
        this.state = state;
    }
    public int getState(){
        return state;
    }
}

Originator�������ˣ���

public class Originator {
    int state;
    public Originator(int state){
        this.state = state;
    }
    void changeState(int state){
        this.state = state;
    }
    Memento saveMemento(){
        return new Memento(state);
    }
    void restoreMemento(Memento memento){
        System.out.println("�ָ���״̬"+memento.getState());
        this.state = memento.getState();
    }
    void displayCurrentState(){
        System.out.println("��ǰ��״̬��:"+state);
    }
}


CareTaker������¼����Ա����

public class CareTaker {
    List<Memento> list =new ArrayList<>();
    public void addMemento(Memento memento){
        list.add(memento);
    }
    public Memento getMemento(int i){
        return list.get(i);
    }
}
Test��

public class Test {
    public static void main(String[] args){
        CareTaker careTaker = new CareTaker();
        Originator originator = new Originator(0);
        Memento memento0 = originator.saveMemento();
        careTaker.addMemento(memento0);
        originator.changeState(1);
        Memento memento1 = originator.saveMemento();
        careTaker.addMemento(memento1);
        originator.changeState(2);
        Memento memento2 = originator.saveMemento();
        careTaker.addMemento(memento2);
        originator.displayCurrentState();
        originator.restoreMemento(careTaker.getMemento(0));
        originator.displayCurrentState();
    }
}
