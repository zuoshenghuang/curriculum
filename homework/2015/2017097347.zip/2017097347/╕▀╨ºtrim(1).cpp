#include <stdio.h>
#include <math.h>
#include <string.h>
#include <stdlib.h>

char *trim(char * a){
   char *c;
   while(*a==' ') a++; 
   c=a;
   while(*a!=' ') a++;
   *(a+1)='\0';
   return c;    
}

int main(){
    char at[101],bt[101];
    char *a,*b;
    int i,j;
    freopen("in.txt","r",stdin);
    freopen("out.txt","w",stdout);
    
    scanf("%s",at);
    scanf("%s",bt);    
    a=trim(at);
    b=trim(bt);

    i=0;
    j=0;
   
    while(b[j]!='\0' && a[i]!='\0'){
        if(a[i]==b[j]) {i++;j++;continue;}
        if(a[i]!=b[j]){i=i-j+1;j=0;}
    } 
    if(a[i]=='\0')
      printf("%d",-1);
    else
      printf("%d",i-j+1);
   
}
