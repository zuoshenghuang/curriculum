#include 
#include 
using namespace std;

void GetMemory(char *p, int num)
{
    p = (char*)malloc(sizeof(char) * num);//ʹ��newҲ�ܹ�������
}

int main(int argc,char** argv)
{
    char *str = NULL;
    GetMemory(str, 100);
    cout<<"Memory leak test!"<
