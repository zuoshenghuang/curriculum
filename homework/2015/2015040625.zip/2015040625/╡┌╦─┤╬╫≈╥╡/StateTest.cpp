#include <iostream>
using namespace std;
class Worker;
//抽象出来的状态类
class State
{
public:
	virtual void doSomething(Worker*w)=0;
};
//状态管理类
class Worker
{
public:
    //初始化状态
    Worker();

    //改变当前的状态
    void setHour(int hour)
    {
        m_hour = hour;
    }
	int getHour()
    {
       return m_hour;
    }
	State*getCurrentState()
	{
		return m_currstate;
	}
	void setCurrentState(State*state)
	{
		m_currstate = state;
	}
	void doSomething()
	{
		m_currstate->doSomething(this);
	}
private:
	State*m_currstate;//对象当前的状态
	int m_hour;
};
//具体的状态子类
class ConcreteStateA:public State
{
public:
    void doSomething(Worker*w);
};
//具体的状态子类
class ConcreteStateB:public State
{
public:
    void doSomething(Worker*w);
};

void ConcreteStateA:: doSomething(Worker*w)
{
	if(w->getHour()==7||w->getHour()==8)
	{
		cout<<"吃早饭"<<endl;
	}
	else
	{
		delete w->getCurrentState();
		w->setCurrentState(new ConcreteStateB);
		w->getCurrentState()->doSomething(w);
	}
}
void ConcreteStateB:: doSomething(Worker*w)
{
	if(w->getHour()==9||w->getHour()==10)
	{
		cout<<"工作"<<endl;
	}
	else
	{
		delete w->getCurrentState();
		w->setCurrentState(new ConcreteStateA);
		//w->getCurrentState()->doSomething(w);
	}
}

Worker::Worker()
{
	m_currstate = new ConcreteStateA;
}

//初始化A状态
int main()
{	
	Worker *w1 = new Worker;
	w1->setHour(7);
	w1->doSomething();

	w1->setHour(9);
	w1->doSomething();

	delete w1;
    getchar();
    return 0;
}
