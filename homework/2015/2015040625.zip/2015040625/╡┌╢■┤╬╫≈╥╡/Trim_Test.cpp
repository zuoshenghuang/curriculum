#include <iostream>
#include <string>
# include<ctime>
clock_t  Begin, End;
double duration;

void trim(std::string & s, char a)
{
    int j=0;
    for(int i=0;i<s.length();i++)
    {
        if(s[i]==a)
        {size_t pos = i;
          s.erase(pos, 1);
        }
        //pos = s.find_first_of(sep);
    }
    ++j;
    std::cout<<"遍历次数："<<j<<std::endl;
}
void test_trim()
{
    std::string str = "my chinese name is Huang xx";
    char a =(char)' ';
    trim(str, a);
    std::cout << str << std::endl;
    
    str = "Brazil,Russia,India,China,South Africa";
    char b = (char)',';
    trim(str, b);
    std::cout << str << std::endl;
    
}

int main()
{
     Begin = clock();//开始计时
    test_trim();
    End = clock();//结束计时
    duration = double(End - Begin) / CLK_TCK;//duration就是运行函数所打的
    //点数,CLK_TCK是每秒所打点数
    std::cout << "tick=" << double(End - Begin) << std::endl;
    std::cout << "duration=" << duration << std::endl;
    system("pause");
    return 0;
}
