// �ڴ�й¶���2.cpp : �������̨Ӧ�ó������ڵ㡣
//

#include "stdafx.h"
#include <iostream>
#include <stdlib.h>
#include "list.h"
using namespace std;


int main() 
{
	List t;
	//InitList(L);
	int i;
	int a1[5] = { 1,2,3,4,5 };
	for (i = 0; i<5; i++) 
		InsertList(t, a1[i], i + 1);
	int *p1 = new int;
	long int a = (long)&p1;
	int *p2 = new int;
	long int b = (long)&p2;
	int *p3 = new int;
	long int c = (long)&p3;
	int *p4 = new int;
	long int d = (long)&p4;
	InsertList(t, a, 0);
	InsertList(t, b, 0);
	InsertList(t, c, 0);
	InsertList(t, d, 0);
	TraverseList(t);
	delete p1;
	DeleteList(t, a, i + 1);
	TraverseList(t);

	return 0;
}
