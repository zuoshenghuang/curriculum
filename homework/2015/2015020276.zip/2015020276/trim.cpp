#include<bits/stdc++.h>
using namespace std;
//code in codeblocks
string trim(string s){
    if(s.empty())
        return s;
    s.erase(0,s.find_first_not_of(" "));
    s.erase(s.find_last_not_of(" ") + 1);
    return s;
}

int main(){
    string s = " Hello World!! ";
    cout << s << " size:" << s.size()<<"\n";
    cout << trim(s) << " size:" << trim(s).size() <<"\n";
    return 0;
}

