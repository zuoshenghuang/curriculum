// trim.cpp : �������̨Ӧ�ó������ڵ㡣
//

#include "stdafx.h"

#include <iostream>
#include <string>
# include<ctime>
using namespace std;

void trim(string & s, string sep)
{
	if (s.empty())
		return;
	for (size_t pos=0; pos < s.length(); pos++) {
		string st = s.substr(pos, sep.size());
		if (st == sep) 
			s.erase(pos,sep.size());
	}
}

void test_trim()
{
	string str = "my chinese name is Huang xx";
	trim(str, "xx");
	cout << str << std::endl;

	str = "Brazil,Russia,India,China,South Africa";
	trim(str, ",");
	cout << str << std::endl;

}

int main()
{
	test_trim();
	system("pause");
	return 0;
}