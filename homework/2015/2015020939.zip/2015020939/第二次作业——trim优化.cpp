#include<string.h>
#include<ctype.h>
char*trim(char *str)
{
    char *p = str; 
    while (*p == ' '||*p=='/t'||*p=='/r'||*p=='/n')
        p++;
    str=p; 
    p=str+strlen(str)-1; 
    while(*p==' '||*p=='/t'||*p=='/r'||*p=='/n')
        --p;
    *(p+1)=0; 
    return str; 
}








