<html>
<head>
<title>$.trim()</title>
<script language="javascript" src="jquery.min.js"></script>
<script language="javascript">
var sString = " 1234567890 ";
sString = $.trim(sString);
alert(sString.length);
</script>
</head>
<body>
</body>
</html>
