#define _CRTDBG_MAP_ALLOC
#include <stdlib.h>
#include <crtdbg.h>
 
#include <iostream>
#include <string>
void test_string()
{
	std::string a = "my ";
	std::string b("chinese");
	std::string c = a + b + " name";	

	std::cout << c << std::endl;
	std::cout << "string c length is:\t" << c.length() << std::endl;
	std::cout << "string c size is:\t" << c.size() << std::endl;

	std::string me = "��";
	std::cout << me << std::endl;
	std::cout << me.size() << std::endl;
	std::cout << me.length() << std::endl;

	const char * str = c.c_str();
	std::cout << "const char * str:\t" << str << std::endl;
	const char ch = c.at(3);
	std::cout << "c.at(3):\t" << ch <<std::endl;
}

void test_use()
{
	using namespace std;

	string str = "my chinese name";

	string sub = str.substr(4, 8); //(��ʼλ�ã��ƶ���Զ)

	std::cout << "sub is:\t" << sub << std::endl;

	size_t pos = str.find(" ");
	std::cout << "find:\t" << pos << std::endl;
	pos = str.find_last_of(" ");
	std::cout << "find last:\t" << pos << std::endl;
}

/*
	һ���ۺϵ�СӦ�ã�����ַ�����ָ�����ַ�
	ΪʲôҪ�����ã�
*/
void trim(std::string & s, std::string sep)

{
    //int i=0;
    if (s.empty())
        return;
    for(int pos;pos<s.length();pos++)
    {
        std::string a=s.substr(pos,sep.size());//��ȡ������ַ�
        if(a==sep)
            s.erase(pos,sep.size());
    

	}
}

void test_trim()
{
	std::string str = "my chinese name is Huang xx";
	trim(str, " ");
	std::cout << str << std::endl;

	str = "Brazil,Russia,India,China,South Africa";
	trim(str, ",");
	std::cout << str << std::endl;

}

int main()
{
//	test_string();
//	test_use();
	test_trim();
	system("pause");
    return 0;
}


