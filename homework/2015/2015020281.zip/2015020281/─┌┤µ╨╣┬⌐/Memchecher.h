#pragma once

struct MemIns
{
	void * pMem;
int m_nSize;
char m_szFileName[256];
int m_nLine;
MemIns * pNext;
};
class MemManager
{
public:
	MemManager();
	~MemManager();
private:
	MemIns *m_pMemInsHead;
	int m_nTotal;
public:
	static MemManager* GetInstance();
	void Append(MemIns *pMemIns);
	void Remove(void *ptr);
	void Dump();

};
void *operator new(size_tsize, const char *szFile, int nLine);
void operator delete(void *ptr, const char *szFile, int nLine);
void operator delete(void *ptr);
void *operator new[](size_tsize, const char *szFile, int nLine);
void operator delete[](void *ptr, const char *szFile, int nLine);
void operator delete[](void *ptr);
