// ConsoleApplication3.cpp : �������̨Ӧ�ó������ڵ㡣
//

#include "stdafx.h"

#include <iostream>

#include "building.h"

 using namespace std;
 class SiegeTank;

 void main()
{
	   concreteBuilding cb("��Ӫ");
	     cb.production();
	     cb.injured();
	   cb.repair();
	     cb.show();
	    return;
	 }
